
package Main_Class;


public class main_rectangulo {

    
    public static void main(String[] args) {

    }
    
}
