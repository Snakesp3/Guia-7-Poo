
package Main_Class;


public class Main_Ejercicio_6 {

    
    public static void main(String[] args) {
        
    }
    
}
